# -*- coding: utf-8 -*-

{
    'name': "Bitodoo datas",

    'summary': """Bitodoo datas""",

    'description': """

    # Bitodoo datas
    """,
    'author': "Bitodoo",
    'website': "http://www.bitodoo.com",
    'category': 'Others',
    'version': '0.1',

    'depends': ['base'],

    'data': [
        'security/ir.model.access.csv',
        'data/bo.datas.csv',
        'views/datas_views.xml',
    ],

    'demo': [
    ],
    'application': True,
}
