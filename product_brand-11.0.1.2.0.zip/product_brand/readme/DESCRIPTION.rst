This module allows odoo users to easily manage product brands.
